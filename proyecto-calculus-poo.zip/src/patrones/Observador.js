/**
 * PATRÓN: Observer (Observador)
 * RESPONSABILIDAD: Gestionar eventos y notificaciones entre componentes
 */
export class Observador {
  constructor() {
    this.suscriptores = new Map()
  }

  suscribir(evento, callback) {
    if (!this.suscriptores.has(evento)) {
      this.suscriptores.set(evento, [])
    }
    this.suscriptores.get(evento).push(callback)
  }

  desuscribir(evento, callback) {
    if (this.suscriptores.has(evento)) {
      const callbacks = this.suscriptores.get(evento)
      const index = callbacks.indexOf(callback)
      if (index > -1) {
        callbacks.splice(index, 1)
      }
    }
  }

  notificar(evento, datos) {
    if (this.suscriptores.has(evento)) {
      this.suscriptores.get(evento).forEach((callback) => {
        callback(datos)
      })
    }
  }

  limpiar() {
    this.suscriptores.clear()
  }
}
