/**
 * PATRÓN: Factory (Fábrica)
 * RESPONSABILIDAD: Crear instancias de escenarios y propiedades
 */
import { PropiedadLinealidad } from "../entidades/PropiedadLinealidad.js"
import { PropiedadAditividad } from "../entidades/PropiedadAditividad.js"
import { PropiedadInversionLimites } from "../entidades/PropiedadInversionLimites.js"
import { PropiedadComparacion } from "../entidades/PropiedadComparacion.js"

export class FabricaEscenarios {
  static crearPropiedad(tipoPropiedad) {
    switch (tipoPropiedad) {
      case "linealidad":
        return new PropiedadLinealidad()
      case "aditividad":
        return new PropiedadAditividad()
      case "inversion-limites":
        return new PropiedadInversionLimites()
      case "comparacion":
        return new PropiedadComparacion()
      default:
        throw new Error(`Propiedad no reconocida: ${tipoPropiedad}`)
    }
  }

  static crearFuncion(tipo, parametros) {
    // Importación dinámica para evitar dependencias circulares
    const { FuncionMatematica } = require("../entidades/FuncionMatematica.js")
    return new FuncionMatematica(tipo, parametros)
  }
}
