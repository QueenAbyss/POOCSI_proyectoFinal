/**
 * ENTIDAD: ParticionRiemann
 * RESPONSABILIDAD: Representar una partición del intervalo para sumas de Riemann
 */
export class ParticionRiemann {
  constructor(intervalo, numeroParticiones) {
    this.intervalo = intervalo
    this.numeroParticiones = numeroParticiones
    this.puntos = []
    this.deltaX = 0
    this.generarPuntos()
  }

  generarPuntos() {
    const { inicio, fin } = this.intervalo
    this.deltaX = (fin - inicio) / this.numeroParticiones

    this.puntos = []
    for (let i = 0; i <= this.numeroParticiones; i++) {
      this.puntos.push(inicio + i * this.deltaX)
    }
  }

  obtenerSubintervalo(indice) {
    if (indice < 0 || indice >= this.numeroParticiones) {
      throw new Error("Índice fuera de rango")
    }
    return {
      inicio: this.puntos[indice],
      fin: this.puntos[indice + 1],
    }
  }

  obtenerPuntoMedio(indice) {
    const subintervalo = this.obtenerSubintervalo(indice)
    return (subintervalo.inicio + subintervalo.fin) / 2
  }

  obtenerPuntoIzquierdo(indice) {
    return this.puntos[indice]
  }

  obtenerPuntoDerecho(indice) {
    return this.puntos[indice + 1]
  }
}
