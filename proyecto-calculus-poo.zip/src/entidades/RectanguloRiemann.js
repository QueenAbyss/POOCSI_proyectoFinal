/**
 * ENTIDAD: RectanguloRiemann
 * RESPONSABILIDAD: Representar un rectángulo individual en la suma de Riemann
 */
export class RectanguloRiemann {
  constructor(base, altura, posicionX) {
    this.base = base
    this.altura = altura
    this.posicionX = posicionX
    this.area = base * altura
    this.color = this.generarColor()
  }

  calcularArea() {
    return this.area
  }

  generarColor() {
    const hue = (Math.abs(this.altura) * 30) % 360
    return `hsl(${hue}, 70%, 60%)`
  }

  obtenerCoordenadas() {
    return {
      x: this.posicionX,
      y: 0,
      ancho: this.base,
      alto: this.altura,
    }
  }
}
