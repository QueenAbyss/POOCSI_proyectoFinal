/**
 * Entidad: ReglaIntegracion
 * Responsabilidad: Representar una regla de integración
 * SRP: Solo almacena información de la regla, no realiza cálculos
 */
export class ReglaIntegracion {
  constructor(nombre, patron, formula, ejemplo) {
    this.nombre = nombre // "Regla de la Potencia", "Regla Exponencial", etc.
    this.patron = patron // patrón de la función (ej: "x^n")
    this.formula = formula // fórmula de integración (ej: "x^(n+1)/(n+1) + C")
    this.ejemplo = ejemplo // ejemplo de uso
    this.dificultad = "basica" // 'basica', 'intermedia', 'avanzada'
  }

  setDificultad(dificultad) {
    this.dificultad = dificultad
  }
}
